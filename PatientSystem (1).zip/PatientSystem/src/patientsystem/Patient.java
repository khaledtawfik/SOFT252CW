
package patientsystem;

import java.util.Scanner;
import java.util.ArrayList;


public class Patient extends User  {
    

    public Patient()
    {
        super();
    }
    
    public Patient(String ID, String password, String name)
    {
        super(ID, password, name);
    }
    
    public Patient(String ID, String password, String firstname, String name, int age, String gender)
    {
        super(ID, password, firstname, name, age, gender);
    }
    
    public Patient(String ID, String password, String firstname, String name, int age, String gender, Address address)
    {
        super(ID, password, firstname, name, age, gender, address);
    }
    
    public String chooseDoctor(){        
        Scanner doctorChoice = new Scanner(System.in);
        return doctorChoice.nextLine();
    }
    
    public void viewDoctorRatings(){ 
        displayDoctorList();
        String doctorChoice = chooseDoctor();
        for (int i = 0; i < AccountList.doctorAccounts.size(); i++) {
            Doctor currentDoctor = AccountList.doctorAccounts.get(i);
            if(currentDoctor.ID.equals(doctorChoice)){
                System.out.println("Rating for Doctor \"" + currentDoctor.getName() + "\": " + currentDoctor.getRating());
            }
        }
    }
    
    public void rateDoctor(){
        displayDoctorList();
        String doctorChoice = chooseDoctor();
        System.out.println("Enter Rating:");
        Scanner input= new Scanner(System.in);
        String doctorRating = input.nextLine();
        
        for (int i = 0; i < AccountList.doctorAccounts.size(); i++) {
            Doctor currentDoctor = AccountList.doctorAccounts.get(i);
            if(currentDoctor.ID.equals(doctorChoice)){
                currentDoctor.setRating(Integer.parseInt(doctorRating));
                System.out.println("Rating added for Doctor \"" + currentDoctor.getName() + "\"");
            }
        }
        
    }
    
    public void feedbackMessage(){
        displayDoctorList();
        String doctorChoice = chooseDoctor();
        System.out.println("Enter Feedback Message:");
        Scanner input= new Scanner(System.in);
        String doctorFeedback = input.nextLine();
        
        for (int i = 0; i < AccountList.doctorAccounts.size(); i++) {
            Doctor currentDoctor = AccountList.doctorAccounts.get(i);
            if(currentDoctor.ID.equals(doctorChoice)){
                currentDoctor.setFeedback(doctorFeedback);
                System.out.println("Feedback added for Doctor \"" + currentDoctor.getName() + "\"");
            }
        }
        
    }
    
    public void requestAppointment(){
        this.displayDoctorList();
        String doctorChoice = chooseDoctor();
        
        for (int i = 0; i < AccountList.doctorAccounts.size(); i++) {
            Doctor currentDoctor = AccountList.doctorAccounts.get(i);
            if(currentDoctor.ID.equals(doctorChoice)){
                // display available times
                System.out.println("Below are the available times:");
                ArrayList<String> times = currentDoctor.getAvailableTimes();
                for (int j = 0; j < times.size(); j++) {
                    System.out.println(times.get(j));
                }
                System.out.println("Enter a date:");
                Scanner input = new Scanner(System.in);
                String choosenTime =  input.nextLine();
                AppointmentRequest request = new AppointmentRequest(this, currentDoctor, choosenTime);
                AccountList.appointmentRequests.add(request);
            }
        }
        
        System.out.println("Request for Appointment created, pending approval");
        
    }
    
    
    
    public void displayDoctorList(){
        System.out.println("Enter doctor's ID from the below list:");
        for (int i = 0; i < AccountList.doctorAccounts.size(); i++) {
            Doctor currentDoctor = AccountList.doctorAccounts.get(i);
            System.out.println(currentDoctor.getID() + ": " + currentDoctor.getName());
            
        }
    }
    
    
    public void viewAppointment(){
        Boolean appointment = false;
        for (int i = 0; i < AccountList.appointments.size(); i++) {
            Appointment currentAppointment = AccountList.appointments.get(i);
            if(currentAppointment.getPatient().getID().equals(this.getID())){
                appointment = true;
                System.out.println("Appointment Time");
                System.out.println(currentAppointment.getAppoitmentTime());
                
                System.out.println("Doctor");
                System.out.println(currentAppointment.getDoctor().getName() + "\n");
            }
            
        }
        if (appointment == false){
            System.out.println("No appointments found");
        }
    }
    
    public void viewPrescription(){
        Boolean prescription = false;
        for (int i = 0; i < AccountList.prescriptions.size(); i++) {
            Prescription currentPrescription = AccountList.prescriptions.get(i);
            if(currentPrescription.getPatient().getID().equals(this.ID)){
                prescription = true;
                System.out.println("\n Prescription:");
                System.out.println("Patient");
                System.out.println("Name: " + currentPrescription.getPatient().getFirstname() + " " + currentPrescription.getPatient().getName());
                System.out.println("Address: " + currentPrescription.getPatient().getAddress().getStreet() + ", " + currentPrescription.getPatient().getAddress().getCity() + ", " + currentPrescription.getPatient().getAddress().getZipcode());
                System.out.println("Sex: " + currentPrescription.getPatient().getGender());
                System.out.println("Age: " + currentPrescription.getPatient().getAge());
                
                System.out.println("\n Doctor");
                System.out.println("Name: " + currentPrescription.getDoctor().getFirstname() + " " + currentPrescription.getDoctor().getName());
                System.out.println("Address: " + currentPrescription.getDoctor().getAddress().getStreet() + ", " + currentPrescription.getDoctor().getAddress().getCity() + ", " + currentPrescription.getDoctor().getAddress().getZipcode());
                
                System.out.println("\n Notes:");
                System.out.println(currentPrescription.getNotes());
                
                System.out.println("\n Medicine:");
                System.out.println(currentPrescription.getMedicine().getMedicineName());
                
                System.out.println("\n Quanitity:");
                System.out.println(currentPrescription.getQuantity());
                
                System.out.println("\n Dosage:");
                System.out.println(currentPrescription.getDosage());
                
            }
        }
        if (prescription == false){
            System.out.println("No prescription found");
        }
    }
    
    public void requestAccountTermination(){
        AccountList.patientDeletionRequest.add(this);
        System.out.println("Request for termination created, pending approval");
        
    }
    @Override
    protected void viewMenuOptions() {
        System.out.println("Patient Options, enter one of the following numbers:");
        
        System.out.println("1- Rate doctors");
        System.out.println("2- Provide feedback messages");
        System.out.println("3- View doctors’ ratings");
        System.out.println("4- Request appointment");
        System.out.println("5- View prescription");
        System.out.println("6- View appointment");
        System.out.println("7- Request account termination");
        System.out.println("Press E to sign out of Patient");
        
    }    
            
}
