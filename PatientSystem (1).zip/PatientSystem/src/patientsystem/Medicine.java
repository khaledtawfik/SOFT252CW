
package patientsystem;

public class Medicine {
    
    String medicineID;
    String medicineName;
    
    public Medicine() {
    }

    public Medicine(String medicineID, String medicineName) {
        this.medicineID = medicineID;
        this.medicineName = medicineName;
    }

    public String getMedicineID() {
        return medicineID;
    }

    public void setMedicineID(String medicineID) {
        this.medicineID = medicineID;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }
    
    
}
