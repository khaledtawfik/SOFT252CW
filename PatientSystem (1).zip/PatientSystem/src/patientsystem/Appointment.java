
package patientsystem;


public class Appointment {
    private Patient patient;
    private Doctor doctor;
    private String appoitmentTime;

    public Appointment(Patient patient, Doctor doctor, String appoitmentTime) {
        this.patient = patient;
        this.doctor = doctor;
        this.appoitmentTime = appoitmentTime;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public String getAppoitmentTime() {
        return appoitmentTime;
    }

    public void setAppoitmentTime(String appoitmentTime) {
        this.appoitmentTime = appoitmentTime;
    }

    
    
}
