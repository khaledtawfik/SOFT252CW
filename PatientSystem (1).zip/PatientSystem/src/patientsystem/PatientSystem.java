package patientsystem;

import java.util.Scanner;

public class PatientSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        AccountList userAccounts = new AccountList();
        userAccounts.AddInitialAccounts();

        AccountsManagement accountsMang = new AccountsManagement();
        while (true) {
            String userRole = accountsMang.chooseUserRole();

            if (!"|A|D|P|S|E".contains(userRole)) {
                System.out.println("Invalid choice");
            }
            if (userRole.equals("E")) {
                System.exit(0);
            }
            if (userRole.equals("P")) {
                System.out.println("Enter N to request New patient account");
                System.out.println("Enter L for patient Login");
                Scanner input = new Scanner(System.in);
                String patientChoice = input.nextLine();

                if (patientChoice.equals("N")) {
                    PatientAccountRequest patientaccountrequest = new PatientAccountRequest();
                    patientaccountrequest.addAccountInformation();
                } else if (patientChoice.equals("L")) {
                    accountsMang.showLoginScreen();
                    Patient patient = accountsMang.PatientLogin();
                    if (patient != null) {
                        while (true) {
                            System.out.println("");

                            patient.viewMenuOptions();
                            String choice = patient.chooseFromMenu();

                            if (choice.equals("1")) { // 1- Rate doctors 
                                patient.rateDoctor();
                            } else if (choice.equals("2")) { // 2- Provide feedback messages

                            } else if (choice.equals("3")) { // 3- View doctors’ ratings
                                patient.viewDoctorRatings();
                            } else if (choice.equals("4")) { // 4- Request appointment
                                patient.requestAppointment();
                            } else if (choice.equals("5")) { // 5- View prescription
                                patient.viewPrescription();
                            } else if (choice.equals("6")) { // 6- View appointment
                                patient.viewAppointment();
                            } else if (choice.equals("7")) { // 7- Request account termination
                                patient.requestAccountTermination();
                            } else if (choice.equals("E")) {
                                break;
                            }

                        }
                    } else {
                        System.out.println("User name or password incorrect");
                    }
                } else {
                    System.out.println("Invalid choice");
                }
            } else {
                accountsMang.showLoginScreen();

                if (userRole.equals("D")) {
                    Doctor doctor = accountsMang.DoctorLogin();
                    if (doctor != null) {
                        while (true) {
                            System.out.println("");

                            doctor.viewMenuOptions();
                            String doctorChoice = doctor.chooseFromMenu();

                            if (doctorChoice.equals("1")) { // 1- View appointments
                                doctor.viewAppointments();
                            } else if (doctorChoice.equals("2")) { // 2- Create new prescription
                                doctor.createNewPrescription();
                            } else if (doctorChoice.equals("3")) { // 3- Make notes during a consultation
                                doctor.addNotes();
                            } else if (doctorChoice.equals("4")) { // 4- Prescribe medicines and dosages
                                doctor.prescribeMedicinesDosages();
                            } else if (doctorChoice.equals("E")) {
                                break;
                            }

                        }
                    } else {
                        System.out.println("User name or password incorrect");
                    }
                } else if (userRole.equals("S")) {
                    Secretary secretary = accountsMang.SecretaryLogin();
                    if (secretary != null) {
                        while (true) {
                            System.out.println("");

                            secretary.viewMenuOptions();
                            String choice = secretary.chooseFromMenu();
                            if (choice.equals("1")) { // 1- Approve patient accounts 
                                secretary.approvePatientAccounts();
                            } else if (choice.equals("2")) { // 2- Receive and create requests for appointments
                                secretary.receiveAppointmentRequests();
                            } else if (choice.equals("3")) { // 3- Remove patients
                                secretary.removePatient();
                            } else if (choice.equals("4")) { // 4- Approve account removal request from patients
                                secretary.approvePatientRemoval();
                            } else if (choice.equals("E")) {
                                break;
                            }

                        }
                    } else {
                        System.out.println("User name or password incorrect");
                    }
                } else if (userRole.equals("A")) {

                    Administrator admin = accountsMang.AdminLogin();
                    if (admin != null) {
                        while (true) {
                            System.out.println("");

                            admin.viewMenuOptions();
                            String adminchoice = admin.chooseFromMenu();

                            if (adminchoice.equals("1")) {  // 1- Add doctor
                                admin.AddDoctor();
                            } else if (adminchoice.equals("2")) { //2- Remove doctor
                                admin.removeDoctor();
                            } else if (adminchoice.equals("3")) { // 3- Add secretary
                                admin.AddSecretary();
                            } else if (adminchoice.equals("4")) { // 4- Remove secretary
                                admin.removeSecretary();
                            } else if (adminchoice.equals("5")) { // 5- View the ratings of the doctors
                                admin.viewDoctorRatings();
                            } else if (adminchoice.equals("E")) {
                                break;
                            }

                        }
                    } else {
                        System.out.println("User name or password incorrect");
                    }

                }

            }
        }
    }

}
