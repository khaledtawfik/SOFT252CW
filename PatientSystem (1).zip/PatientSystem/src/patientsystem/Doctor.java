
package patientsystem;
import java.util.ArrayList;
import java.util.Scanner;


public class Doctor extends User  {
    
    private int rating;
    private String feedback;
    private ArrayList<String> availableTimes = new ArrayList<>();

    public Doctor()
    {
        super();
    }
    
    public Doctor(String ID, String password, String name, int rating)
    {
        super(ID, password, name);
        this.rating = rating;
    }
    
    public Doctor(String ID, String password, String firstname, String name, int age, String gender)
    {
        super(ID, password, firstname, name, age, gender);
    }
    
    public Doctor(String ID, String password, String name, int rating, ArrayList<String> availableTimes)
    {
        super(ID, password, name);
        this.rating = rating;
        this.availableTimes = availableTimes;
    }

    public Doctor(String ID, String password, String firstname, String name, Address address, int rating, ArrayList<String> availableTimes) {
        super(ID, password, firstname, name, address);
        this.rating = rating;
        this.availableTimes = availableTimes;
    }
    
    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    
    public ArrayList<String> getAvailableTimes() {
        return availableTimes;
    }

    public void setAvailableTimes(ArrayList<String> availableTimes) {
        this.availableTimes = availableTimes;
    }
    
    
    
    public void createNewPrescription(){
        
        System.out.println("Creating new prescription:");
        System.out.println("Enter patient ID");
        
        Scanner input = new Scanner(System.in);
        String patientID =  input.nextLine();
        
        for (int i = 0; i < AccountList.patientAccounts.size(); i++) {
            Patient currentPatient;
            currentPatient = AccountList.patientAccounts.get(i);
            if(currentPatient.ID.equals(patientID)){
                Prescription newPrescription = new Prescription(currentPatient, this);
                AccountList.prescriptions.add(newPrescription);
                System.out.println("Prescription created for patient: " + currentPatient.getName());

            }
        }
    }
    
    public void addNotes(){
        System.out.println("Adding notes:");
        System.out.println("Enter patient ID");
        
        Scanner input = new Scanner(System.in);
        String patientID =  input.nextLine();
        
        // search for patient prescription
        for (int i = 0; i < AccountList.prescriptions.size(); i++) {
            Prescription currentPrescription = AccountList.prescriptions.get(i);
            if (currentPrescription.getPatient().getID().equals(patientID)) {
                   System.out.println("Enter notes");
                   Scanner input2 = new Scanner(System.in);
                   String notes =  input2.nextLine();
                   currentPrescription.setNotes(notes);
            }
        }
    }
    public void prescribeMedicinesDosages(){
        System.out.println("Prescribing medicines and dosages:");
        System.out.println("Enter patient ID");
        
        Scanner input = new Scanner(System.in);
        String patientID =  input.nextLine();
        
        // search for patient prescription
        for (int i = 0; i < AccountList.prescriptions.size(); i++) {
            Prescription currentPrescription = AccountList.prescriptions.get(i);
            if (currentPrescription.getPatient().getID().equals(patientID)) {
                   System.out.println("Enter medicine ID from available list:");
                   // Display all medicines
                   for (int j = 0; j < AccountList.medicineList.size(); j++) {
                       Medicine currentMedicine = AccountList.medicineList.get(j);
                       System.out.println(currentMedicine.getMedicineID() + ": " + currentMedicine.getMedicineName());
                   }
            
                   Scanner input2 = new Scanner(System.in);
                   String choosenMedicineID =  input2.nextLine();
                   for (int j = 0; j < AccountList.medicineList.size(); j++) {
                       Medicine currentMedicine = AccountList.medicineList.get(j);
                       if(currentMedicine.getMedicineID().equals(choosenMedicineID)){
                           currentPrescription.setMedicine(currentMedicine);
                           System.out.println("Medicine has been added");
                       }
                   }
                   System.out.println("\n Enter Quantity");
                   Scanner input3 = new Scanner(System.in);
                   String quantity =  input3.nextLine();
                   currentPrescription.setQuantity(Integer.parseInt(quantity));
                   System.out.println("Quantity has been added");
                   
                   System.out.println("\n Enter Dosage");
                   Scanner input4 = new Scanner(System.in);
                   String dosage =  input4.nextLine();
                   currentPrescription.setDosage(dosage);
                   System.out.println("Dosage has been added");
                   
            }
        }
    }
    
    public void createNewMedicine(){
        
        System.out.println("Create new medicine");
        System.out.println("Enter medicine ID");
        
        Scanner input = new Scanner(System.in);
        String medicineID =  input.nextLine();
        
        System.out.println("Enter medicine name");
        
        Scanner input2 = new Scanner(System.in);
        String medicineName =  input2.nextLine();
        
        Medicine newmedicine = new Medicine(medicineID, medicineName);
        AccountList.medicineList.add(newmedicine);
    }
    
    public void viewAppointments(){
        Boolean appointment = false;
        for (int i = 0; i < AccountList.appointments.size(); i++) {
            Appointment currentAppointment = AccountList.appointments.get(i);
            if (currentAppointment.getDoctor().getID().equals(this.ID)) {
                appointment = true;
                System.out.println("Appointments for doctor " + this.name + ": \n");
                System.out.println("Appointment time: " + currentAppointment.getAppoitmentTime());
                System.out.println("Patient ID: " + currentAppointment.getPatient().getID());
                System.out.println("Patient Name: " + currentAppointment.getPatient().getName());
                
            }
        }
        if (appointment == false){
            System.out.println("No appointments found");
        }
    }
    
    @Override
    protected void viewMenuOptions() {
        System.out.println("Doctor Options, enter one of the following numbers:");
        
        System.out.println("1- View appointments");
        System.out.println("2- Create new prescription");
        System.out.println("3- Make notes during a consultation");
        System.out.println("4- Prescribe medicines and dosages");
        System.out.println("5- Create new medicines");
        System.out.println("6- Inspect patient history");
        System.out.println("7- Propose and create future appointments for a specific patient");
        System.out.println("Press E to sign out of Doctor");
        
    }
    
}
