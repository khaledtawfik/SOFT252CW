package patientsystem;

import java.util.Scanner;

public class Secretary extends User {

    public Secretary() {
        super();
    }

    public Secretary(String ID, String password, String name) {
        super(ID, password, name);
    }

    public Secretary(String ID, String password, String firstname, String name, int age, String gender) {
        super(ID, password, firstname, name, age, gender);
    }

    public void receiveAppointmentRequests() {
        if (AccountList.appointmentRequests.size() > 0) {
            System.out.println("Below are the requests for appointments: \n");
            for (int i = 0; i < AccountList.appointmentRequests.size(); i++) {

                AppointmentRequest currentRequest = AccountList.appointmentRequests.get(i);
                System.out.println("Appointment Request ID: " + i);
                System.out.println("Requesting patient ID: " + currentRequest.getRequestingPatient().getID());
                System.out.println("Requesting patient Name: " + currentRequest.getRequestingPatient().getName());
                System.out.println("Requested doctor ID: " + currentRequest.getChoosenDoctor().getID());
                System.out.println("Requested doctor Name: " + currentRequest.getChoosenDoctor().getName());
                System.out.println("Selected time: " + currentRequest.getChoosenTime() + "\n\n");

            }
            System.out.println("Enter the Appointment Request ID to confirm an appointment:");
            Scanner input = new Scanner(System.in);
            String appointmentRequestID = input.nextLine();
            AppointmentRequest requestData = AccountList.appointmentRequests.get(Integer.parseInt(appointmentRequestID));

            Appointment confirmedAppointment = new Appointment(requestData.getRequestingPatient(), requestData.getChoosenDoctor(), requestData.getChoosenTime());
            AccountList.appointments.add(confirmedAppointment);
            AccountList.appointmentRequests.remove(requestData);
            System.out.println("Appointment " + appointmentRequestID + " has been confirmed");
        } else {
            System.out.println("No appointment requests");
        }

    }

    public void approvePatientAccounts() {
        if (AccountList.patientAccountRequest.size() > 0) {
            System.out.println("Patient accounts requests will be displayed: \n");
            for (int i = 0; i < AccountList.patientAccountRequest.size(); i++) {
                System.out.println("Request number " + i + 1 + " :");

                PatientAccountRequest currentRequest = AccountList.patientAccountRequest.get(i);
                System.out.println("Patient ID: " + currentRequest.getID());
                System.out.println("Patient first name: " + currentRequest.getFirstname());
                System.out.println("Patient last name: " + currentRequest.getName());
                System.out.println("Patient age: " + currentRequest.getAge());
                System.out.println("Patient gender: " + currentRequest.getGender() + "\n");

                System.out.println("Press 1 to approve or any other key to decline");
                Scanner input = new Scanner(System.in);
                String choice = input.nextLine();

                if (Integer.parseInt(choice) == 1) {
                    Patient approvedPatientAccount = new Patient(currentRequest.getID(), currentRequest.getPassword(), currentRequest.getFirstname(), currentRequest.getName(), currentRequest.getAge(), currentRequest.getGender());
                    AccountList.patientAccounts.add(approvedPatientAccount);
                    AccountList.patientAccountRequest.remove(currentRequest);
                    System.out.println("Patient account approved.");
                }
            }
        } else {
            System.out.println("No patient requests");
        }
    }

    public void removePatient() {
        System.out.println("Enter patient ID to remove");
        Scanner input = new Scanner(System.in);
        String patientID = input.nextLine();

        for (int i = 0; i < AccountList.patientAccounts.size(); i++) {
            Patient currentPatient = AccountList.patientAccounts.get(i);
            if (currentPatient.ID.equals(patientID)) {
                AccountList.patientAccounts.remove(currentPatient);
                System.out.println("Patient account removed.");
            }
        }
    }

    public void approvePatientRemoval() {
        if (AccountList.patientDeletionRequest.size() > 0) {
            System.out.println("Patient removal requests will be displayed: \n");
            for (int i = 0; i < AccountList.patientDeletionRequest.size(); i++) {
                System.out.println("Request number " + i + 1 + " :");

                Patient currentPatient = AccountList.patientDeletionRequest.get(i);
                System.out.println("Patient ID: " + currentPatient.getID());
                System.out.println("Patient first name: " + currentPatient.getFirstname());
                System.out.println("Patient last name: " + currentPatient.getName() + "\n");

                System.out.println("Press 1 to approve removal of account or any other key to decline");
                Scanner input = new Scanner(System.in);
                String choice = input.nextLine();

                if (Integer.parseInt(choice) == 1) {
                    AccountList.patientAccounts.remove(currentPatient);
                    AccountList.patientDeletionRequest.remove(currentPatient);
                    System.out.println("Patient account removed.");
                }
            }
        } else {
            System.out.println("No patient deletion requests");
        }

    }

    @Override
    protected void viewMenuOptions() {
        System.out.println("Secretary Options, enter one of the following numbers:");

        System.out.println("1- Approve patient accounts");
        System.out.println("2- Receive and create requests for appointments");
        System.out.println("3- Remove patients");
        System.out.println("4- Approve account removal request from patients");
        System.out.println("Press E to sign out of Secretary");

    }

}
