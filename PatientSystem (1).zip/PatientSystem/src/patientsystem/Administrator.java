
package patientsystem;

import java.util.Scanner;


public class Administrator extends User  {
    

    public Administrator()
    {
        super();
    }
    
    public Administrator(String ID, String password, String name)
    {
        super(ID, password, name);
    }

    public void AddDoctor(){
        
        System.out.println("Enter ID"); 
        Scanner input1 = new Scanner(System.in);
        String doctorID = input1.nextLine();
        
        System.out.println("Enter Password");
        Scanner input2 = new Scanner(System.in);
        String doctorPassword = input2.nextLine();
        
        System.out.println("Enter first name"); 
        Scanner input3 = new Scanner(System.in);
        String doctorFirstName = input3.nextLine();
        
        System.out.println("Enter last name");
        Scanner input4 = new Scanner(System.in);
        String doctorLastName = input4.nextLine();
        
        System.out.println("Enter age"); 
        Scanner input5 = new Scanner(System.in);
        int doctorAge = Integer.parseInt(input5.nextLine());
        
        System.out.println("Enter gender");
        Scanner input6 = new Scanner(System.in);
        String doctorGender = input6.nextLine();
        
    
        Doctor newDoctor = new Doctor(doctorID, doctorPassword, doctorFirstName, doctorLastName, doctorAge, doctorGender);
        AccountList.doctorAccounts.add(newDoctor);
        System.out.println("Doctor Account created");
        
    }
    
    public void removeDoctor (){
        System.out.println("Enter doctor ID to remove");
        Scanner input = new Scanner(System.in);
        String doctorID = input.nextLine();
        
        for (int i = 0; i < AccountList.doctorAccounts.size(); i++) {
            Doctor currentDoctor = AccountList.doctorAccounts.get(i);
            if(currentDoctor.ID.equals(doctorID)){
                AccountList.doctorAccounts.remove(currentDoctor);
                System.out.println("Doctor account removed");
            }
        }
    }
    
    
    public void AddSecretary(){
        
        System.out.println("Enter ID"); 
        Scanner input1 = new Scanner(System.in);
        String secID = input1.nextLine();
        
        System.out.println("Enter Password");
        Scanner input2 = new Scanner(System.in);
        String secPassword = input2.nextLine();
        
        System.out.println("Enter first name"); 
        Scanner input3 = new Scanner(System.in);
        String secFirstName = input3.nextLine();
        
        System.out.println("Enter last name");
        Scanner input4 = new Scanner(System.in);
        String secLastName = input4.nextLine();
        
        System.out.println("Enter age"); 
        Scanner input5 = new Scanner(System.in);
        int secAge = Integer.parseInt(input5.nextLine());
        
        System.out.println("Enter gender");
        Scanner input6 = new Scanner(System.in);
        String secGender = input6.nextLine();
        
    
        Secretary newSecretary = new Secretary(secID, secPassword, secFirstName, secLastName, secAge, secGender);
        AccountList.secretaryAccounts.add(newSecretary);
        System.out.println("Secretary Account created");
        
    }
    
    public void removeSecretary (){
        System.out.println("Enter secretary ID to remove");
        Scanner input = new Scanner(System.in);
        String secID = input.nextLine();
        
        for (int i = 0; i < AccountList.secretaryAccounts.size(); i++) {
            Secretary currentSec = AccountList.secretaryAccounts.get(i);
            if(currentSec.ID.equals(secID)){
                AccountList.secretaryAccounts.remove(currentSec);
                System.out.println("Secretary account removed");
            }
        }
    }
    
    public void viewDoctorRatings(){
        System.out.println("Enter doctor ID"); 
        Scanner input = new Scanner(System.in);
        String doctorID = input.nextLine();
        for (int i = 0; i < AccountList.doctorAccounts.size(); i++) {
            Doctor currentDoctor = AccountList.doctorAccounts.get(i);
            if(currentDoctor.ID.equals(doctorID)){
                System.out.println("Doctor's rating is: " + currentDoctor.getRating());
            }
        }
    }
    
    
    
    @Override
    protected void viewMenuOptions() {
        System.out.println("Administrator Options, enter one of the following numbers:");
        
        System.out.println("1- Add doctor");
        System.out.println("2- Remove doctor");
        System.out.println("3- Add secretary");
        System.out.println("4- Remove secretary");
        System.out.println("5- View the ratings of the doctors");
        System.out.println("6- Provide feedback to each doctor based on ratings and comments from patients");
        System.out.println("Press E to sign out of Administrator");
        
    }
    
}
