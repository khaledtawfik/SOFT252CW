
package patientsystem;

import java.util.Scanner;


public class AccountsManagement {

    private String userName;
    private String password;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String chooseUserRole() {
        System.out.println("\n\nWelcome to Patient Management System");
        System.out.println("Enter a letter according to your role: ");
        System.out.println("Role          Letter");
        System.out.println("Administrator \t A");
        System.out.println("Doctor        \t D");
        System.out.println("Patient       \t P");
        System.out.println("Secretary     \t S");
        System.out.println("Exit          \t E\n");

        Scanner input = new Scanner(System.in);
        String userRole = input.nextLine();

        return userRole;

    }

    public Administrator AdminLogin() {
        Administrator currentadmin;
        for (int i = 0; i < AccountList.adminAccounts.size(); i++) {
            currentadmin = AccountList.adminAccounts.get(i);
            if (currentadmin.ID.equals(this.userName) && currentadmin.password.equals(this.password)) {
                System.out.println("welcome " + currentadmin.getName() + "\n");
                return currentadmin;
            }
        }     
        return null;
    }

    public Doctor DoctorLogin() {
        Doctor currentDoctor;
        for (int i = 0; i < AccountList.doctorAccounts.size(); i++) {
            currentDoctor = AccountList.doctorAccounts.get(i);
            if (currentDoctor.ID.equals(this.userName) && currentDoctor.password.equals(this.password)) {
                System.out.println("welcome " + currentDoctor.getName() + "\n");
                return currentDoctor;
            }
        }
        return null;
    }

    public Patient PatientLogin() {
        Patient currentPatient;
        for (int i = 0; i < AccountList.patientAccounts.size(); i++) {
            currentPatient = AccountList.patientAccounts.get(i);
            if (currentPatient.ID.equals(this.userName) && currentPatient.password.equals(this.password)) {
                System.out.println("welcome " + currentPatient.getName() + "\n");
                return currentPatient;
            }
        }
        return null;
    }

    public Secretary SecretaryLogin() {
        Secretary currentSecretary;
        for (int i = 0; i < AccountList.secretaryAccounts.size(); i++) {
            currentSecretary = AccountList.secretaryAccounts.get(i);
            if (currentSecretary.ID.equals(this.userName) && currentSecretary.password.equals(this.password)) {
                System.out.println("welcome " + currentSecretary.getName() + "\n");
                return currentSecretary;
            }
        }
        return null;
    }

    public void showLoginScreen() {
        System.out.println("Enter user name");
        Scanner input = new Scanner(System.in);
        this.userName = input.nextLine();

        System.out.println("Enter password");
        input = new Scanner(System.in);
        this.password = input.nextLine();

    }
    
    

}
