package patientsystem;

import java.util.ArrayList;

public class AccountList {

    public static ArrayList<Doctor> doctorAccounts = new ArrayList<>();
    public static ArrayList<Patient> patientAccounts = new ArrayList<>();
    public static ArrayList<Administrator> adminAccounts = new ArrayList<>();
    public static ArrayList<Secretary> secretaryAccounts = new ArrayList<>();
    
    public static ArrayList<Prescription> prescriptions = new ArrayList<>();
    public static ArrayList<Medicine> medicineList = new ArrayList<>();
    
    public static ArrayList<AppointmentRequest> appointmentRequests = new ArrayList<>();
    public static ArrayList<Appointment> appointments = new ArrayList<>();
    
    public static ArrayList<PatientAccountRequest> patientAccountRequest = new ArrayList<>();
    public static ArrayList<Patient> patientDeletionRequest = new ArrayList<>();

    
    public void AddInitialAccounts() {

        // Add initial accounts for testings, adding 1 admin, 3 doctors, 3 patients, 1 secretary.
        // Adding 1 admin
        Administrator newAdmin1 = new Administrator("A1", "123", "Admin1");
        AccountList.adminAccounts.add(newAdmin1);

        // Adding 3 doctors
        Address doctor1Address = new Address("Fictitious Clinic, Diagon Alley", "Plymouth", "PL4 8AA", "UK");
        ArrayList<String> doctor1AvailableTimes = new ArrayList<>();
        doctor1AvailableTimes.add("1 Feb 2019");
        doctor1AvailableTimes.add("2 Feb 2019");
        Doctor newDoctor1 = new Doctor("D1", "123", "Serina", "James", doctor1Address, 5, doctor1AvailableTimes);
        
        ArrayList<String> doctor2AvailableTimes = new ArrayList<>();
        doctor2AvailableTimes.add("23 Feb 2019");
        doctor2AvailableTimes.add("25 Feb 2019");
        Doctor newDoctor2 = new Doctor("D2", "456", "Doctor2", 1, doctor2AvailableTimes);
        
        Doctor newDoctor3 = new Doctor("D3", "789", "Doctor3", 3);
        AccountList.doctorAccounts.add(newDoctor1);
        AccountList.doctorAccounts.add(newDoctor2);
        AccountList.doctorAccounts.add(newDoctor3);

        // Adding 3 patients
        Address patientAddress = new Address("Portland Square Building", "Plymouth", "PL4 8AA", "UK");
        Patient newPatient1 = new Patient("P1", "1234", "John", "Doe", 45, "Male", patientAddress);
        Patient newPatient2 = new Patient("P2", "5678", "Patient2");
        Patient newPatient3 = new Patient("P3", "2345", "Patient3");
        AccountList.patientAccounts.add(newPatient1);
        AccountList.patientAccounts.add(newPatient2);
        AccountList.patientAccounts.add(newPatient3);

        // Adding 1 secretary
        Secretary newSec1 = new Secretary("S1", "123", "Secretary1");
        AccountList.secretaryAccounts.add(newSec1);
        
        // Adding 10 medicines
        Medicine medicine1 = new Medicine("M1", "AFRINOL");
        Medicine medicine2 = new Medicine("M2", "SUDAFED");
        Medicine medicine3 = new Medicine("M3", "TYLENOL");
        Medicine medicine4 = new Medicine("M4", "NEXIUM");
        Medicine medicine5 = new Medicine("M5", "HALDOL");
        Medicine medicine6 = new Medicine("M6", "MINOCIN");
        Medicine medicine7 = new Medicine("M7", "DILANTIN");
        Medicine medicine8 = new Medicine("M8", "MOTRIN");
        Medicine medicine9 = new Medicine("M9", "Ibuprofen");
        Medicine medicine10 = new Medicine("M10", "Phenytoin");

        AccountList.medicineList.add(medicine1);
        AccountList.medicineList.add(medicine2);
        AccountList.medicineList.add(medicine3);
        AccountList.medicineList.add(medicine4);
        AccountList.medicineList.add(medicine5);
        AccountList.medicineList.add(medicine6);
        AccountList.medicineList.add(medicine7);
        AccountList.medicineList.add(medicine8);
        AccountList.medicineList.add(medicine9);
        AccountList.medicineList.add(medicine10);

                                                
    }

}
