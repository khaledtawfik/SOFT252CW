
package patientsystem;

import java.util.Scanner;



public class PatientAccountRequest {
    private String ID;
    private String password;
    private String firstname;
    private String name;
    private int age;
    private String gender;

    public PatientAccountRequest() {
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public void addAccountInformation(){
        System.out.println("Enter ID"); 
        Scanner input1 = new Scanner(System.in);
        this.ID = input1.nextLine();
        
        System.out.println("Enter Password");
        Scanner input2 = new Scanner(System.in);
        this.password = input2.nextLine();
        
        System.out.println("Enter first name"); 
        Scanner input3 = new Scanner(System.in);
        this.firstname = input3.nextLine();
        
        System.out.println("Enter last name");
        Scanner input4 = new Scanner(System.in);
        this.name = input4.nextLine();
        
        System.out.println("Enter age"); 
        Scanner input5 = new Scanner(System.in);
        this.age = Integer.parseInt(input5.nextLine());
        
        System.out.println("Enter gender");
        Scanner input6 = new Scanner(System.in);
        this.gender = input6.nextLine();
        
        AccountList.patientAccountRequest.add(this);
        System.out.println("Account created, pending approval");
        
    }

}
