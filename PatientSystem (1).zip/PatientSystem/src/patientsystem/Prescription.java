
package patientsystem;


public class Prescription {
    
    Patient patient;
    Doctor doctor;
    String notes;
    Medicine medicine;
    int quantity;
    String dosage;

    public Prescription(){
        
    }
    
    public Prescription(Patient patient, Doctor doctor){
        this.patient = patient;
        this.doctor = doctor;
    }
    public Prescription(Patient patient, Doctor doctor, String notes, Medicine medicine, int quantity, String dosage) {
        this.patient = patient;
        this.doctor = doctor;
        this.notes = notes;
        this.medicine = medicine;
        this.quantity = quantity;
        this.dosage = dosage;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Medicine getMedicine() {
        return medicine;
    }

    public void setMedicine(Medicine medicine) {
        this.medicine = medicine;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }
    
    
    
}
