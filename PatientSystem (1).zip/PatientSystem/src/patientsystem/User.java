
package patientsystem;

import java.util.Scanner;


public abstract class User{
    protected String ID;
    protected String password;
    protected String firstname;
    protected String name;
    protected int age;
    protected String gender;
    protected Address address;

    public User() {
    }

    public User(String ID, String password, String name) {
        this.ID = ID;
        this.password = password;
        this.name = name;
    }
    
    public User(String ID, String password, String firstname, String name, Address address) {
        this.ID = ID;
        this.password = password;
        this.firstname = firstname;
        this.name = name;
        this.address = address;
    }

    public User(String ID, String password, String firstname, String name, int age, String gender) {
        this.ID = ID;
        this.password = password;
        this.firstname = firstname;
        this.name = name;
        this.age = age;
        this.gender = gender;
    }
    
    public User(String ID, String password, String firstname, String name, int age, String gender, Address address) {
        this.ID = ID;
        this.password = password;
        this.firstname = firstname;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.address = address;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
    
   
    
    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
   
    protected abstract void viewMenuOptions();
    
    protected String chooseFromMenu(){
        Scanner input = new Scanner(System.in);
        String userOption = input.nextLine();
        return userOption;
        
   }
    
    
}
