
package patientsystem;


public class AppointmentRequest {
    
    private int requestID;
    private Patient requestingPatient;
    private Doctor choosenDoctor;
    private String choosenTime;
    
    public AppointmentRequest(Patient requestingPatient, Doctor choosenDoctor, String choosenTime) {
        
        this.requestingPatient = requestingPatient;
        this.choosenDoctor = choosenDoctor;
        this.choosenTime = choosenTime;
    }
    
    public Patient getRequestingPatient() {
        return requestingPatient;
    }

    public void setRequestingPatient(Patient requestingPatient) {
        this.requestingPatient = requestingPatient;
    }

    public Doctor getChoosenDoctor() {
        return choosenDoctor;
    }

    public void setChoosenDoctor(Doctor choosenDoctor) {
        this.choosenDoctor = choosenDoctor;
    }

    public String getChoosenTime() {
        return choosenTime;
    }

    public void setChoosenTime(String choosenTime) {
        this.choosenTime = choosenTime;
    }
    
    

    

}
